﻿#include<iostream>
#include<string>
using namespace std;

static bool isDigit(const string& s)
{
	for (size_t i = 0; i < s.length(); ++i)
		if (s[i] < '0' || s[i] > '9')
			return false;
	return true;
}

static bool isPrime(unsigned long long int n)
{
	for (unsigned long long int i = 2; i <= sqrt(n); ++i)
		if (0 == n % i)
			return false;
	return true;
}

int main()
{
	for (;;)
	{
		cout << "请输入一个正整数：";
		rewind(stdin);
		fflush(stdin);
		string s = "";
		getline(cin, s);
		if ((s.length() <= 19 || s.length() == 20 && s.compare("18446744073709551615") <= 0) && isDigit(s))
		{
			const unsigned long long int n = stoull(s);
			if (n <= 1)
				cout << n << " 既不是素数也不是合数。" << endl << endl;
			else if (isPrime(n))
				cout << n << " 是素数。" << endl << endl;
			else
				cout << n << " 不是素数。" << endl << endl;
		}
		else
			break;
	}
	cout << "检测到非数字字符或输入的不是小于等于 18446744073709551615 的自然数，程序退出。" << endl << endl;
	return EXIT_SUCCESS;
}