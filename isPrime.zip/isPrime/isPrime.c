﻿#include<stdio.h>
#include<math.h>

static bool isPrime(int n)
{
	for (int i = 2; i <= sqrt(n); ++i)
		if (0 == n % i)
			return false;
	return true;
}

int main()
{
	int n = 2;
	rewind(stdin);
	fflush(stdin);
	printf("请输入一个正整数：");
	while (scanf_s("%d", &n) == 1)
	{
		if (n <= 0)
			printf("%d 小于等于 0，本程序仅支持正整数。\n", n);
		else if (1 == n)
			printf("%d 既不是素数也不是合数。\n", n);
		else if (isPrime(n))
			printf("%d 是素数。\n", n);
		else
			printf("%d 不是素数。\n", n);
		rewind(stdin);
		fflush(stdin);
		printf("请输入一个正整数：");
	}
	printf("检测到非数字字符，程序退出。\n\n");
	return 0;
}